document.addEventListener('DOMContentLoaded',()=>{
 const max=2*1024*1024;
 const setup=(id,preview,allowed)=>{
  const input=document.getElementById(id),el=document.getElementById(preview);if(!input||!el)return;
  let objectURL=null;
  input.addEventListener('change',()=>{
   if(objectURL){URL.revokeObjectURL(objectURL);objectURL=null;}
   const file=input.files[0];
   if(!file){if(id==='dokumen')el.textContent='Belum ada dokumen dipilih.';else{el.hidden=true;el.removeAttribute('src');}return;}
   if(!allowed(file)||file.size>max){alert('File '+id+' tidak sesuai tipe atau melebihi 2 MB.');input.value='';if(id==='dokumen')el.textContent='Belum ada dokumen dipilih.';else el.hidden=true;return;}
   if(id==='dokumen'){el.textContent=file.name+' - '+Math.round(file.size/1024)+' KB';return;}
   objectURL=URL.createObjectURL(file);el.src=objectURL;el.hidden=false;
  });
  window.addEventListener('beforeunload',()=>{if(objectURL)URL.revokeObjectURL(objectURL);});
 };
 setup('foto','previewFoto',f=>['image/jpeg','image/png','image/webp'].includes(f.type));
 setup('audio','previewAudio',f=>['audio/mpeg','audio/wav','audio/x-wav','audio/wave','audio/vnd.wave','audio/x-pn-wav'].includes(f.type));
 setup('dokumen','previewDokumen',f=>f.type==='application/pdf');
 const form=document.querySelector('[data-media-form]');
 if(form)form.addEventListener('submit',e=>{
  let valid=true;
  document.querySelectorAll('.form-error').forEach(x=>x.textContent='');document.querySelectorAll('.is-invalid').forEach(x=>x.classList.remove('is-invalid'));
  [['nim','errorNim','NIM wajib diisi.'],['nama','errorNama','Nama wajib diisi.'],['program_studi','errorProdi','Program studi wajib diisi.'],['email','errorEmail','Email tidak valid.']].forEach(([id,err,msg])=>{
   const x=document.getElementById(id);if(!x||!x.value.trim()||(id==='email'&&!x.checkValidity())){valid=false;if(x)x.classList.add('is-invalid');document.getElementById(err).textContent=msg;}
  });
  if(form.dataset.requireFoto==='true'&&!document.getElementById('foto').files.length){document.getElementById('errorFoto').textContent='Foto wajib dipilih.';valid=false;}
  if(!valid){e.preventDefault();alert('Form belum valid. Periksa kembali input Anda.');}
 });
 document.querySelectorAll('.media-delete-form').forEach(x=>x.addEventListener('submit',e=>{if(!confirm('Data dan file media terkait akan dihapus. Lanjutkan?'))e.preventDefault();}));
 const search=document.getElementById('searchMedia');if(search)search.addEventListener('input',()=>{const term=search.value.toLowerCase().trim();document.querySelectorAll('#mediaTable tbody tr').forEach(row=>row.style.display=row.textContent.toLowerCase().includes(term)?'':'none');});
 const status=new URLSearchParams(location.search).get('status');if(['tambah','update','hapus'].includes(status))alert({tambah:'Data media berhasil ditambahkan.',update:'Data media berhasil diperbarui.',hapus:'Data media berhasil dihapus.'}[status]);
});
