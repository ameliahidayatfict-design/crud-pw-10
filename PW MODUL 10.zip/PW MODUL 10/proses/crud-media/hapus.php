<?php
require_once __DIR__.'/../../config/auth.php';require_once __DIR__.'/../../config/koneksi.php';require_once __DIR__.'/../../config/media_helper.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: ../../crud-media/index.php');exit;}
try{
 $id=(int)($_POST['id']??0);if($id<=0)throw new RuntimeException('ID tidak valid.');
 $stmt=$conn->prepare('SELECT foto,audio,dokumen FROM mahasiswa WHERE id=? LIMIT 1');$stmt->bind_param('i',$id);$stmt->execute();$files=$stmt->get_result()->fetch_assoc();$stmt->close();if(!$files)throw new RuntimeException('Data tidak ditemukan.');
 $del=$conn->prepare('DELETE FROM mahasiswa WHERE id=?');$del->bind_param('i',$id);if(!$del->execute())throw new RuntimeException('Hapus data gagal.');$del->close();cleanupSet($files);
 header('Location: ../../crud-media/index.php?status=hapus');exit;
}catch(Throwable $e){http_response_code(400);die('Proses hapus gagal: '.e($e->getMessage()));}
