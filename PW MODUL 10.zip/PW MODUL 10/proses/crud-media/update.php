<?php
require_once __DIR__.'/../../config/auth.php';require_once __DIR__.'/../../config/koneksi.php';require_once __DIR__.'/../../config/media_helper.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: ../../crud-media/index.php');exit;}
$new=['foto'=>null,'audio'=>null,'dokumen'=>null];
try{
 $id=(int)($_POST['id']??0);if($id<=0)throw new RuntimeException('ID tidak valid.');$data=mediaInputText();
 $oldStmt=$conn->prepare('SELECT foto,audio,dokumen FROM mahasiswa WHERE id=? LIMIT 1');$oldStmt->bind_param('i',$id);$oldStmt->execute();$old=$oldStmt->get_result()->fetch_assoc();$oldStmt->close();if(!$old)throw new RuntimeException('Data tidak ditemukan.');
 $new=uploadSet();$final=[];foreach(['foto','audio','dokumen'] as $key)$final[$key]=$new[$key]??$old[$key];
 $stmt=$conn->prepare('UPDATE mahasiswa SET nim=?,nama=?,program_studi=?,email=?,foto=?,audio=?,dokumen=? WHERE id=?');
 $stmt->bind_param('sssssssi',$data['nim'],$data['nama'],$data['program_studi'],$data['email'],$final['foto'],$final['audio'],$final['dokumen'],$id);
 if(!$stmt->execute())throw new RuntimeException('Update database gagal.');$stmt->close();
 $replace=[];foreach($new as $key=>$value)if($value!==null)$replace[$key]=$old[$key];cleanupSet($replace);
 header('Location: ../../crud-media/index.php?status=update');exit;
}catch(Throwable $e){cleanupSet($new);http_response_code(400);die('Proses update gagal: '.e($e->getMessage()));}
