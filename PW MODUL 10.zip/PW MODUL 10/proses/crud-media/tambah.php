<?php
require_once __DIR__.'/../../config/auth.php';require_once __DIR__.'/../../config/koneksi.php';require_once __DIR__.'/../../config/media_helper.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: ../../crud-media/tambah.php');exit;}
$files=['foto'=>null,'audio'=>null,'dokumen'=>null];
try{
 $data=mediaInputText();$files=uploadSet();if($files['foto']===null)throw new RuntimeException('Foto wajib dipilih.');
 $stmt=$conn->prepare('INSERT INTO mahasiswa (nim,nama,program_studi,email,foto,audio,dokumen) VALUES (?,?,?,?,?,?,?)');
 $stmt->bind_param('sssssss',$data['nim'],$data['nama'],$data['program_studi'],$data['email'],$files['foto'],$files['audio'],$files['dokumen']);
 if(!$stmt->execute())throw new RuntimeException('Data gagal disimpan.');$stmt->close();header('Location: ../../crud-media/index.php?status=tambah');exit;
}catch(Throwable $e){cleanupSet($files);http_response_code(400);die('Proses gagal: '.e($e->getMessage()));}
