MODUL 10 - CRUD MEDIA (ADD-ON UNTUK PROJECT afteruts)
====================================================
File ZIP ini berisi bagian BARU modul. Project CRUD Mahasiswa lama tidak disertakan karena tidak diunggah.

1. BACKUP folder project lama dan database web_programming_1.
2. Ekstrak isi ZIP ke folder project lama: C:\laragon\www\afteruts\
   Jika project memakai nama folder lain, ekstrak ke folder itu. Gabungkan, jangan hapus file lama.
3. Pastikan file LAMA masih ada:
   config/auth.php, config/koneksi.php, pages/dashboard.php, crud/index.php.
   config/koneksi.php harus menyediakan variabel $conn berupa koneksi mysqli.
4. Buka Laragon dan Start All. Buka phpMyAdmin dan pilih database web_programming_1.
   Import atau jalankan database/upgrade_modul_10.sql sekali saja (jangan dua kali).
5. Tambahkan link ini ke navbar HALAMAN LAMA di pages/ dan crud/:
   <a href="../crud-media/index.php">CRUD Media</a>
   Penambahan dilakukan manual karena isi navbar proyek lama belum tersedia.
6. Login seperti biasanya, kemudian buka:
   http://localhost/afteruts/crud-media/index.php
   Ganti afteruts jika nama folder project berbeda.
7. Coba Tambah dengan foto JPG/PNG/WEBP <= 2 MB; audio MP3/WAV dan PDF opsional.
8. Coba search, edit tanpa ganti file, edit dengan ganti file, dan hapus (file fisik ikut dihapus).
9. Untuk screenshot bukti: halaman tabel, form tambah, preview, hasil tambah, hasil edit, konfirmasi hapus,
   tabel database dan folder uploads/.

CATATAN:
- Pada Modul 10, field foto wajib saat tambah dan opsional saat edit.
- Semua file maksimum 2 MB. PHP perlu extension fileinfo aktif.
- CSS media.css baru dipisahkan supaya style.css project lama tidak rusak.
- Auth/login mengikuti proyek lama; ZIP ini tidak membuat akun dummy.
- Tidak ada data contoh palsu dalam database.
- File tidak dapat dijalankan mandiri tanpa project sesi sebelumnya dan database lokal.
