-- Jalankan SEKALI pada database web_programming_1 setelah BACKUP
USE web_programming_1;
ALTER TABLE mahasiswa
  ADD foto VARCHAR(255) NULL,
  ADD audio VARCHAR(255) NULL,
  ADD dokumen VARCHAR(255) NULL;
