<?php
function uploadMedia(array $file, array $allowedMime, int $maxSize, string $targetDir, string $prefix): ?string {
    if (!isset($file['error']) || is_array($file['error'])) throw new RuntimeException('Format data upload tidak valid.');
    if ($file['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Upload gagal. Kode: '.$file['error']);
    if ($file['size'] > $maxSize || $file['size'] <= 0) throw new RuntimeException('Ukuran file tidak valid (maks. 2 MB).');
    if (!is_uploaded_file($file['tmp_name'])) throw new RuntimeException('File upload tidak valid.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowedMime[$mime])) throw new RuntimeException('Tipe file tidak diizinkan.');
    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) throw new RuntimeException('Folder upload gagal dibuat.');
    $name=$prefix.'_'.bin2hex(random_bytes(8)).'.'.$allowedMime[$mime];
    if (!move_uploaded_file($file['tmp_name'],rtrim($targetDir,'/\\').DIRECTORY_SEPARATOR.$name)) throw new RuntimeException('File gagal dipindahkan.');
    return $name;
}
function hapusMediaJikaAda(?string $filename,string $targetDir): void {
    if (!$filename) return;
    $path=rtrim($targetDir,'/\\').DIRECTORY_SEPARATOR.basename($filename);
    if (is_file($path)) unlink($path);
}
function mediaRules(): array {return [
 'foto'=>['mime'=>['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'],'dir'=>'images','prefix'=>'img'],
 'audio'=>['mime'=>['audio/mpeg'=>'mp3','audio/wav'=>'wav','audio/x-wav'=>'wav','audio/wave'=>'wav','audio/vnd.wave'=>'wav','audio/x-pn-wav'=>'wav'],'dir'=>'audio','prefix'=>'aud'],
 'dokumen'=>['mime'=>['application/pdf'=>'pdf'],'dir'=>'documents','prefix'=>'doc']
];}
function mediaInputText(): array {
 $fields=[];
 foreach(['nim','nama','program_studi','email'] as $k){$fields[$k]=trim($_POST[$k]??'');if($fields[$k]==='')throw new RuntimeException('Semua field teks wajib diisi.');}
 if (!filter_var($fields['email'],FILTER_VALIDATE_EMAIL))throw new RuntimeException('Format email tidak valid.');
 return $fields;
}
function uploadSet(): array {
 $out=['foto'=>null,'audio'=>null,'dokumen'=>null];
 $rules=mediaRules();$root=__DIR__.'/../uploads';
 try {foreach($rules as $key=>$r){$out[$key]=uploadMedia($_FILES[$key]??[],$r['mime'],2*1024*1024,$root.'/'.$r['dir'],$r['prefix']);}}
 catch(Throwable $e){cleanupSet($out);throw $e;}
 return $out;
}
function cleanupSet(array $files): void {foreach(mediaRules() as $key=>$r)hapusMediaJikaAda($files[$key]??null,__DIR__.'/../uploads/'.$r['dir']);}
function e($v):string{return htmlspecialchars((string)($v??''),ENT_QUOTES,'UTF-8');}
